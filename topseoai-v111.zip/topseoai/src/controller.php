<?php

function getTopseolog()
{
    return TOPSEOHelper::getRestResponse(json_decode(get_option(TOPSEO_DEBUG_DEFINITION), true));
}

function getCategories()
{
    $categories = get_categories(
        array(
            'hide_empty' => false,
            'orderby' => 'id',
            'order' => 'ASC'
        )
    );

    return TOPSEOHelper::getRestResponse(array_map(function ($e) {
        $result = array(
            'id' => $e->term_id,
            'name' => $e->name,
            'slug' => $e->slug
        );
        if ($e->category_parent != 0) {
            $result['parent'] = $e->category_parent;
        }
        return $result;
    }, $categories));
}

function postArticle(WP_REST_Request $request)
{
    $params = $request->get_params();
    $paramsPost = isset($params['post_data']) ? $params['post_data'] : array();
    $paramsOptions = isset($params['post_options']) ? $params['post_options'] : array();
    $paramsConfig = isset($params['post_config']) ? $params['post_config'] : array();

    $contentDownloadImage = TOPSEODownloadImageContent($paramsPost['post_content'], $paramsConfig);
    if ($contentDownloadImage instanceof WP_Error) {
        TOPSEOHelper::addDebugging("post::TOPSEODownloadImageContent", TOPSEOHelper::WPError2Response($contentDownloadImage));
        return $contentDownloadImage;
    }

    $paramsPost['post_content'] = $contentDownloadImage;

    if (isset($paramsPost['ID'])) {
        $resultPost = TOPSEOUpdatePost($paramsPost);
    } else {
        $resultPost = TOPSEOAddPost($paramsPost);
    }

    if ($resultPost instanceof WP_Error) {
        TOPSEOHelper::addDebugging("POST::TOPSEODownloadImageContent", TOPSEOHelper::WPError2Response($resultPost));
        return $resultPost;
    }

    $resultSetCategory = TOPSEOAddCategories($resultPost, $paramsOptions);

    if ($resultSetCategory instanceof WP_Error) {
        TOPSEOHelper::addDebugging("POST::TOPSEODownloadImageContent", TOPSEOHelper::WPError2Response($resultSetCategory));
        return $resultSetCategory;
    }

    $resultSetFeaturedImage = TOPSEOAddFeaturedImage($resultPost, $paramsOptions);

    if ($resultSetFeaturedImage instanceof WP_Error) {
        TOPSEOHelper::addDebugging("POST::TOPSEODownloadImageContent", TOPSEOHelper::WPError2Response($resultSetFeaturedImage));
        return $resultSetFeaturedImage;
    }

    $resultSetTags = TOPSEOAddTags($resultPost, $paramsOptions);

    if ($resultSetTags instanceof WP_Error) {
        TOPSEOHelper::addDebugging("POST::TOPSEODownloadImageContent", TOPSEOHelper::WPError2Response($resultSetTags));
        return $resultSetTags;
    }

    $resultSetPostFormat = TOPSEOAddPostFormat($resultPost, $paramsOptions);

    if ($resultSetPostFormat instanceof WP_Error) {
        TOPSEOHelper::addDebugging("POST::TOPSEODownloadImageContent", TOPSEOHelper::WPError2Response($resultSetPostFormat));
        return $resultSetPostFormat;
    }

    return TOPSEOHelper::getRestResponse(array(
        "id" => $resultPost,
        "status" => true,
        "permalink" => get_permalink($resultPost)
    ));
}

function postVerify(WP_REST_Request $request)
{
    TOPSEOHelper::setOption(TOPSEO_API_KEY_VERIFY, 1);

    return TOPSEOHelper::getRestResponse(array(
        "status" => true
    ));
}

function postVersion(WP_REST_Request $request)
{
    $version = $request->get_param('version');
    TOPSEOHelper::setOption(TOPSEO_LAST_VERSION_DEFINITION, $version);
    return TOPSEOHelper::getRestResponse(array(
        "status" => true,
        "version" => $version
    ));
}