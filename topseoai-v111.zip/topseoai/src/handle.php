<?php

function TOPSEOAddPost($params)
{
    return wp_insert_post($params, true);
}

function TOPSEOUpdatePost($params)
{
    return wp_update_post($params, true);
}

function TOPSEOAddCategories($postId, $params)
{
    $taxCategory = TOPSEOHelper::shiftParam($params, TOPSEO_POST_CATE_NAME, 'category');
    $postCategories = TOPSEOHelper::shiftParam($params, TOPSEO_POST_CATEGORIES, '');
    return wp_set_post_terms($postId, $postCategories, $taxCategory);
}

function TOPSEOAddFeaturedImage($postId, $params)
{
    $imageFile = TOPSEOHelper::shiftParam($params, TOPSEO_POST_FEATURED_IMAGE);
    if (isset($imageFile)) {
        $attachId = TOPSEOHelper::wpInsertAttachmentFromUrl($imageFile);
        set_post_thumbnail($postId, $attachId);

        return $attachId;
    }

    return 0;
}

function TOPSEOAddTags($postId, $params)
{
    $tags = TOPSEOHelper::shiftParam($params, TOPSEO_POST_TAGS);
    if (isset($tags)) {
        return wp_set_post_tags($postId, $tags);
    }

    return 0;
}

function TOPSEOAddPostFormat($postId, $params)
{
    $postFormat = TOPSEOHelper::shiftParam($params, TOPSEO_POST_FORMAT);
    if (isset($postFormat)) {
        return wp_set_post_terms($postId, $postFormat, TOPSEO_POST_FORMAT);
    }

    return 0;
}

function TOPSEODownloadImageContent($content, $params)
{
    $downloadImageConfig = TOPSEOHelper::shiftParam($params, TOPSEO_CONFIG_DOWNLOAD_IMAGE);
    if (isset($downloadImageConfig) && $downloadImageConfig == 1) {
        // Get all images in content
        $document = new DOMDocument();
        $document->loadHTML(mb_convert_encoding($content, 'HTML-ENTITIES', 'UTF-8'), LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        $imageList = $document->getElementsByTagName('img');

        foreach ($imageList as $image) {
            $imageUrl = $imageDataSrc = $image->getAttribute("data-src");
            $imageSrc = $image->getAttribute("src");
            if (empty($imageUrl)) {
                $imageUrl = $imageSrc;
            }

            $attachId = TOPSEOHelper::wpInsertAttachmentFromUrl($imageUrl);
            if ($attachId instanceof WP_Error) {
                $attachId->add_data(array(
                    'img' => $imageUrl,
                    'content' => $content
                ));
                return $attachId;
            }
            $localImageUrl = wp_get_attachment_url($attachId);
            $content = str_replace($imageDataSrc, $localImageUrl, $content);
            $pos = strpos($content, $imageSrc);

            if ($pos !== false) {
                $content = substr_replace($content, $localImageUrl, $pos, strlen($imageSrc));
            }

            unset($imageDataSrc);
            unset($imageSrc);
        }
    }

    return $content;
}
