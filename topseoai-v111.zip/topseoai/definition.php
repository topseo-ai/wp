<?php

define("TOPSEO_TICKS_SUCCESS", 'PGRpdiBjbGFzcz0ibXpocnR0bHRwIj48c3ZnIGNsYXNzPSJ0b3BzZW8tdGlja3Mtc3VjY2VzcyIgZmlsbD0iY3VycmVudENvbG9yIiB2aWV3Qm94PSIwIDAgMTYgMTYiPjxwYXRoIGQ9Ik0xNiA4QTggOCAwIDEgMSAwIDhhOCA4IDAgMCAxIDE2IDB6bS0zLjk3LTMuMDNhLjc1Ljc1IDAgMCAwLTEuMDguMDIyTDcuNDc3IDkuNDE3IDUuMzg0IDcuMzIzYS43NS43NSAwIDAgMC0xLjA2IDEuMDZMNi45NyAxMS4wM2EuNzUuNzUgMCAwIDAgMS4wNzktLjAybDMuOTkyLTQuOTlhLjc1Ljc1IDAgMCAwLS4wMS0xLjA1eiI+PC9wYXRoPjwvc3ZnPjxkaXYgY2xhc3M9ImhydHRsdHB0eHQiPiVzPC9kaXY+PC9kaXY+');
define("TOPSEO_TICKS_FAILED", 'PGRpdiBjbGFzcz0ibXpocnR0bHRwIj48c3ZnIGNsYXNzPSJ0b3BzZW8tdGlja3MtZmFpbGVkIHRvcHNlby10b29sdGlwIiBmaWxsPSJjdXJyZW50Q29sb3IiIHZpZXdCb3g9IjAgMCA1MTIgNTEyIj48cGF0aCBkPSJNMjU2IDMyYzE0LjIgMCAyNy4zIDcuNSAzNC41IDE5LjhsMjE2IDM2OGM3LjMgMTIuNCA3LjMgMjcuNyAuMiA0MC4xUzQ4Ni4zIDQ4MCA0NzIgNDgwSDQwYy0xNC4zIDAtMjcuNi03LjctMzQuNy0yMC4xcy03LTI3LjggLjItNDAuMWwyMTYtMzY4QzIyOC43IDM5LjUgMjQxLjggMzIgMjU2IDMyem0wIDEyOGMtMTMuMyAwLTI0IDEwLjctMjQgMjRWMjk2YzAgMTMuMyAxMC43IDI0IDI0IDI0czI0LTEwLjcgMjQtMjRWMTg0YzAtMTMuMy0xMC43LTI0LTI0LTI0em0zMiAyMjRjMC0xNy43LTE0LjMtMzItMzItMzJzLTMyIDE0LjMtMzIgMzJzMTQuMyAzMiAzMiAzMnMzMi0xNC4zIDMyLTMyeiI+PC9wYXRoPjwvc3ZnPjxkaXYgY2xhc3M9ImhydHRsdHB0eHQiPiVzPC9kaXY+PC9kaXY+');

define("TOPSEO_HASH_DEFINITION", '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_#@{}",/:.');
define("TOPSEO_HASH_MAPPING", '7xk6mG50tc2DQJoLb/@8X}I,jnZYOMV#Rs_.FB:AUhHprW{e-qKzE1PTNC39l"4awdvfiugyS');
define("TOPSEO_API_KEY_DEFINITION", "topseo_api_key");
define("TOPSEO_API_KEY_VERIFY", "topseo_api_key_verify");
define("TOPSEO_USER_UPDATE_DEFINITION", "topseo_user_update");
define("TOPSEO_DEBUG_DEFINITION", "topseo_debug");

define("TOPSEO_API_ENDPOINT", "https://app.topseo.ai/api");
define("TOPSEO_API_VERIFY_PATH", "/verify");
define("TOPSEO_API_VALIDATE_PATH", "/validate");
define("TOPSEO_API_SYNC_CATEGORIES_PATH", "/sync_categories");
define("TOPSEO_API_NAMESPACE", "topseo/v1");

define("TOPSEO_POST_CATE_NAME", 'post_category_name');
define("TOPSEO_POST_CATEGORIES", 'post_categories');
define("TOPSEO_POST_FEATURED_IMAGE", 'post_featured_image');
define("TOPSEO_POST_TAGS", 'post_tags');
define("TOPSEO_POST_FORMAT", 'post_format');

define("TOPSEO_CONFIG_DOWNLOAD_IMAGE", 'download_images');
define("TOPSEO_INTRODUCE_SETTING", 'topseo_introduce_setting');
define("TOPSEO_PACKAGE_INFO", 'https://app.topseo.ai/api/wpinfo');

define("TOPSEO_MESSAGE_FAILED_DEFAULT", 'No Response From Server app.topseo.ai');
define("TOPSEO_PLUGIN_ACTIVATE", 'topseo_plugin_activate');

define("TOPSEO_DEBUG_LIMITATION", 1000);
define("TOPSEO_DEBUG_EXPIRED", 604800);
define("TOPSEO_CHECK_VALIDATED", false);
define("TOPSEO_LAST_VERSION_DEFINITION", 'topseo_last_version');
define("TOPSEO_CURRENT_VERSION_DEFINITION", 'topseo_current_version');

