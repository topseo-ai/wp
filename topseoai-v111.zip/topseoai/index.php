<?php
/**
 * Plugin Name: TOPSEO.AI
 * Plugin URI:  https://topseo.ai
 * Description: Sync data between TOPSEO.AI and Wordpress site
 * Version:     1.1.1
 * Author:      TOPSEO.AI
 * Author URI:  https://www.facebook.com/groups/topseoai
 * Update URI:  https://app.topseo.ai/api/wpinfo
 *
 * @package Meta Box
 */

include_once __DIR__ . "/router.php";
include_once __DIR__ . "/definition.php";
include_once __DIR__ . "/utils/request.php";
include_once __DIR__ . "/utils/hash.php";
include_once __DIR__ . "/utils/helper.php";
include_once __DIR__ . "/src/controller.php";
include_once __DIR__ . "/src/handle.php";
include_once __DIR__ . "/src/register_bulk.php";
include_once __DIR__ . "/src/register_menu.php";
include_once __DIR__ . "/src/register_form.php";
include_once __DIR__ . "/src/validation.php";
include_once __DIR__ . "/update.php";

add_action('upgrader_process_complete', 'my_upgrade_function', 10, 2);
register_activation_hook(__FILE__, 'topseoai_activate');
register_deactivation_hook(__FILE__, 'topseoai_deactivate');

function topseoai_activate()
{
    $pluginActivate = get_option(TOPSEO_PLUGIN_ACTIVATE);
    $optionPluginActivateMethod = !$pluginActivate ? 'add_option' : 'update_option';
    if ($pluginActivate != 1) {
        $optionPluginActivateMethod(TOPSEO_PLUGIN_ACTIVATE, 1);
        TOPSEOHelper::addInfo("PLUGIN::ACTIVATE", "YES");
    }
}

function topseoai_deactivate()
{
    $pluginActivate = get_option(TOPSEO_PLUGIN_ACTIVATE);
    $optionPluginActivateMethod = !$pluginActivate ? 'add_option' : 'update_option';
    if ($pluginActivate != 0) {
        $optionPluginActivateMethod(TOPSEO_PLUGIN_ACTIVATE, 0);
        TOPSEOHelper::addInfo("PLUGIN::ACTIVATE", "NO");
    }
}

function my_upgrade_function($upgraderObject, $options)
{
    $currentPluginPathName = plugin_basename(__FILE__);

    if ($options['action'] == 'update' && $options['type'] == 'plugin') {
        foreach ($options['plugins'] as $eachPlugin) {
            if ($eachPlugin == $currentPluginPathName) {
                TOPSEOHelper::setOption(TOPSEO_CURRENT_VERSION_DEFINITION, get_option(TOPSEO_LAST_VERSION_DEFINITION));
            }
        }
    }
}
