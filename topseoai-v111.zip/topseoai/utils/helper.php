<?php

final class TOPSEOHelper
{
    public static function shiftParam(&$parameters, $key, $default = null)
    {
        if (isset($parameters[$key])) {
            $result = $parameters[$key];
            unset($parameters[$key]);
            return $result;
        }

        return $default;
    }

    public static function wpInsertAttachmentFromUrl($url, $parentPostId = null)
    {
        if (!class_exists('WP_Http')) {
            require_once ABSPATH . WPINC . '/class-http.php';
        }

        if(!function_exists('wp_get_current_user')) {
            include(ABSPATH . "wp-includes/pluggable.php");
        }

        $http = new WP_Http();
        $response = $http->request($url);

        if ($response instanceof WP_Error) {
            return $response;
        }

        if (200 !== $response['response']['code']) {
            return false;
        }

        $upload = wp_upload_bits(basename($url), null, $response['body']);
        if (!empty($upload['error'])) {
            return false;
        }

        $filePath = $upload['file'];
        $fileName = basename($filePath);
        $fileType = wp_check_filetype($fileName, null);
        $attachmentTitle = sanitize_file_name(pathinfo($fileName, PATHINFO_FILENAME));
        $wpUploadDir = wp_upload_dir();

        $postInfo = array(
            'guid' => $wpUploadDir['url'] . '/' . $fileName,
            'post_mime_type' => $fileType['type'],
            'post_title' => $attachmentTitle,
            'post_content' => '',
            'post_status' => 'inherit',
        );

        // Create the attachment.
        $attachId = wp_insert_attachment($postInfo, $filePath, $parentPostId, true);

        // Include image.php.
        require_once ABSPATH . 'wp-admin/includes/image.php';

        // Generate the attachment metadata.
        $attachData = wp_generate_attachment_metadata($attachId, $filePath);

        // Assign metadata to attachment.
        wp_update_attachment_metadata($attachId, $attachData);

        return $attachId;
    }

    public static function addInfo($callback, $message)
    {
        $info = array(
            'type' => 'information',
            'callback' => $callback,
            'message' => $message,
            'time' => time()
        );

        $topseoInfo = get_option(TOPSEO_DEBUG_DEFINITION);

        if (!$topseoInfo) {
            $optionInfoMethod = 'add_option';
            $topseoInfo = json_encode(array($info));
        } else {
            $optionInfoMethod = 'update_option';
            $topseoInfo = json_decode($topseoInfo, true);
            $topseoInfo = self::removeDebugging($topseoInfo);
            $topseoInfo[] = $info;
            $topseoInfo = json_encode($topseoInfo);
        }

        $optionInfoMethod(TOPSEO_DEBUG_DEFINITION, $topseoInfo);
    }

    public static function addDebugging($callback, $response)
    {
        $response = json_decode($response, true);
        if (isset($response['status'], $response['code']) && !$response['status'] && $response['code'] == 0) {
            $debug = array(
                'type' => 'error',
                'callback' => $callback,
                'message' => $response['message'],
                'time' => time()
            );

            if (isset($response['data'])) {
                $debug['data'] = $response['data'];
            }
            $topseoDebug = get_option(TOPSEO_DEBUG_DEFINITION);

            if (!$topseoDebug) {
                $optionDebugMethod = 'add_option';
                $topseoDebug = json_encode(array($debug));
            } else {
                $optionDebugMethod = 'update_option';
                $topseoDebug = json_decode($topseoDebug, true);
                $topseoDebug = self::removeDebugging($topseoDebug);
                $topseoDebug[] = $debug;
                $topseoDebug = json_encode($topseoDebug);
            }

            $optionDebugMethod(TOPSEO_DEBUG_DEFINITION, $topseoDebug);
        }
    }

    public static function removeDebugging($debugList)
    {
        while (count($debugList) > TOPSEO_DEBUG_LIMITATION) {
            array_shift($debugList);
        }

        return array_values(array_filter($debugList, function ($e) {
            return time() - TOPSEO_DEBUG_EXPIRED < $e['time'];
        }));
    }

    public static function WPError2Response(WP_Error $error)
    {
        return json_encode(array(
            'status' => false,
            'code' => $error->get_error_code(),
            'message' => $error->get_error_message(),
            'data' => $error->get_error_data()
        ));
    }

    public static function setOption($key, $value)
    {
        $opt = get_option($key);
        $func = $opt === false ? 'add_option' : 'update_option';
        $func($key, $value);
    }

    public static function getDataTransfer()
    {
        $lang = get_option('WPLANG');

        if (empty($lang)) {
            $lang = 'en';
        }

        $lang = explode('_', $lang)[0];
        return TOPSEOHash::encode(json_encode(array(
            'uid' => get_current_user_id(),
            'lang' => $lang,
            'domain' => $_SERVER['SERVER_NAME']
        )));
    }

    public static function getRestResponse($response)
    {
        $wpResponse = new WP_REST_Response($response);
        $wpResponse->header('Data-Transfer', self::getDataTransfer());
        return $wpResponse;
    }
}