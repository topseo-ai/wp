<?php

add_filter('bulk_actions-edit-category', function ($bulk_actions) {
    $bulk_actions['sync-to-topseo'] = __('Synchronize to TOPSEO.ai');
    return $bulk_actions;
});

add_filter('handle_bulk_actions-edit-category', function ($redirect_url, $action, $post_ids) {
    if ($action == 'sync-to-topseo') {
        $resultSync = TOPSEORequest::syncCategories(get_option(TOPSEO_API_KEY_DEFINITION));
        if ($resultSync['status']) {
            add_settings_error(
                'topseo_sync_success',
                'sync-categories-success',
                'Synchronized all categories !!',
                'success'
            );
        } else {
            add_settings_error(
                'topseo_sync_errors',
                'sync-categories-failed',
                $resultSync['message'],
                'error'
            );
        }
        $redirect_url = add_query_arg('sync-to-topseo', count($post_ids), $redirect_url);
    }
    return $redirect_url;
}, 10, 3);

add_action('admin_notices', function () {
    if (!empty($_REQUEST['sync-to-topseo'])) {
        printf('<div id="message" class="updated notice is-dismissable"><p>' . __('Synchronized all categories !!') . '</p></div>');
    }
});