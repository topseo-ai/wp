<div class="wrap">
    <h1><?php echo get_admin_page_title() ?></h1>
    <form method="post" action="options.php">
        <?php
        settings_errors( 'topseo_settings_errors' );
        settings_fields( 'topseo_settings' );
        do_settings_sections( 'topseo_settings' );
        submit_button();
        ?>
    </form>
</div>