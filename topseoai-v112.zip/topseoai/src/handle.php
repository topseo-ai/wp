<?php

function TOPSEOAddPost($params, $isStream = false)
{
    remove_filter('content_save_pre', 'wp_filter_post_kses');
    remove_filter('excerpt_save_pre', 'wp_filter_post_kses');
    remove_filter('content_filtered_save_pre', 'wp_filter_post_kses');
    $result = wp_insert_post($params, true);
    if ($isStream) {
        if ($result instanceof WP_Error) {
            TOPSEOHelper::output(array(
                'status' => false,
                'code' => $result->get_error_code(),
                'message' => $result->get_error_message(),
                'action' => 'TOPSEOAddPost',
                'data' => $params
            ));
        } else {
            TOPSEOHelper::output(array(
                'status' => true,
                'action' => 'TOPSEOAddPost',
                'data' => $params
            ));
        }
    }

    return $result;
}

function TOPSEOUpdatePost($params, $isStream = false)
{
    remove_filter('content_save_pre', 'wp_filter_post_kses');
    remove_filter('excerpt_save_pre', 'wp_filter_post_kses');
    remove_filter('content_filtered_save_pre', 'wp_filter_post_kses');
    $result = wp_update_post($params, true);
    if ($isStream) {
        if ($result instanceof WP_Error) {
            TOPSEOHelper::output(array(
                'status' => false,
                'code' => $result->get_error_code(),
                'message' => $result->get_error_message(),
                'action' => 'TOPSEOUpdatePost',
                'data' => $params
            ));
        } else {
            TOPSEOHelper::output(array(
                'status' => true,
                'action' => 'TOPSEOUpdatePost',
                'data' => $params
            ));
        }
    }

    return $result;
}

function TOPSEOAddCategories($postId, $params, $isStream = false)
{
    $taxCategory = TOPSEOHelper::shiftParam($params, TOPSEO_POST_CATE_NAME, 'category');
    $postCategories = TOPSEOHelper::shiftParam($params, TOPSEO_POST_CATEGORIES, '');
    $result = wp_set_post_terms($postId, $postCategories, $taxCategory);
    if ($isStream) {
        if ($result instanceof WP_Error) {
            TOPSEOHelper::output(array(
                'status' => false,
                'code' => $result->get_error_code(),
                'message' => $result->get_error_message(),
                'action' => 'TOPSEOAddCategories',
                'data' => array(
                    'taxonomy' => $taxCategory,
                    'category' => $postCategories
                )
            ));
        } else {
            TOPSEOHelper::output(array(
                'status' => true,
                'action' => 'TOPSEOAddCategories',
                'data' => array(
                    'taxonomy' => $taxCategory,
                    'category' => $postCategories
                )
            ));
        }
    }

    return $result;
}

function TOPSEOAddFeaturedImage($postId, $params, $isStream = false)
{
    $imageFile = TOPSEOHelper::shiftParam($params, TOPSEO_POST_FEATURED_IMAGE);
    $result = 0;
    if (isset($imageFile) && !empty($imageFile)) {
        $attachId = TOPSEOHelper::wpInsertAttachmentFromUrl($imageFile);
        if ($isStream) {
            if ($attachId instanceof WP_Error) {
                TOPSEOHelper::output(array(
                    'status' => false,
                    'code' => $attachId->get_error_code(),
                    'message' => $attachId->get_error_message(),
                    'action' => 'TOPSEOAddFeaturedImage',
                    'data' => array(
                        'src' => $imageFile
                    )
                ));
            } else {
                TOPSEOHelper::output(array(
                    'status' => true,
                    'action' => 'TOPSEOAddFeaturedImage',
                    'data' => array(
                        'src' => $imageFile
                    )
                ));
            }
        }
        set_post_thumbnail($postId, $attachId);
        $result = $attachId;
    }

    return $result;
}

function TOPSEOAddTags($postId, $params, $isStream = false)
{
    $tags = TOPSEOHelper::shiftParam($params, TOPSEO_POST_TAGS);
    $result = 0;

    if (isset($tags)) {
        $result = wp_set_post_tags($postId, $tags);
        if ($isStream) {
            if ($result instanceof WP_Error) {
                TOPSEOHelper::output(array(
                    'status' => false,
                    'code' => $result->get_error_code(),
                    'message' => $result->get_error_message(),
                    'action' => 'TOPSEOAddTags',
                    'data' => array(
                        'tags' => $tags
                    )
                ));
            } else {
                TOPSEOHelper::output(array(
                    'status' => true,
                    'action' => 'TOPSEOAddTags',
                    'data' => array(
                        'tags' => $tags
                    )
                ));
            }
        }
    }

    return $result;
}

function TOPSEOAddPostFormat($postId, $params, $isStream = false)
{
    $postFormat = TOPSEOHelper::shiftParam($params, TOPSEO_POST_FORMAT);
    $result = 0;

    if (isset($postFormat)) {
        $result = wp_set_post_terms($postId, $postFormat, TOPSEO_POST_FORMAT);
        if ($isStream) {
            if ($result instanceof WP_Error) {
                TOPSEOHelper::output(array(
                    'status' => false,
                    'code' => $result->get_error_code(),
                    'message' => $result->get_error_message(),
                    'action' => 'TOPSEOAddPostFormat',
                    'data' => array(
                        'format' => $postFormat
                    )
                ));
            } else {
                TOPSEOHelper::output(array(
                    'status' => true,
                    'action' => 'TOPSEOAddPostFormat',
                    'data' => array(
                        'format' => $postFormat
                    )
                ));
            }
        }
    }

    return $result;
}

function TOPSEODownloadImageContent($content, $params, $isStream = false)
{
    $downloadImageConfig = TOPSEOHelper::shiftParam($params, TOPSEO_CONFIG_DOWNLOAD_IMAGE);
    if (isset($downloadImageConfig) && $downloadImageConfig == 1) {
        // Get all images in content
        $document = new DOMDocument();
        $document->loadHTML(mb_convert_encoding($content, 'HTML-ENTITIES', 'UTF-8'), LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        $imageList = $document->getElementsByTagName('img');

        foreach ($imageList as $image) {
            $imageUrl = $imageDataSrc = $image->getAttribute("data-src");
            $imageSrc = $image->getAttribute("src");
            if (empty($imageUrl)) {
                $imageUrl = $imageSrc;
            }

            if (empty($imageUrl)) {
                continue;
            }

            if (strpos($imageUrl, '{MY_REDIRECT_PREFIX}') !== false) {
                $imageUrl = str_replace('{MY_REDIRECT_PREFIX}', '', $imageUrl);
            }

            if (strpos($imageUrl, '{MYIMAGE_URL}') !== false) {
                $imageUrl = str_replace('{MYIMAGE_URL}', 'https://at0.topseo.work', $imageUrl);
            }

            $attachId = TOPSEOHelper::wpInsertAttachmentFromUrl($imageUrl);

            if ($attachId instanceof WP_Error) {
                $attachId->add_data(array(
                    'img' => $imageUrl,
                    'content' => $content
                ));

                if ($isStream) {
                    TOPSEOHelper::output(array(
                        'status' => false,
                        'code' => $attachId->get_error_code(),
                        'message' => $attachId->get_error_message(),
                        'action' => 'TOPSEODownloadImageContent',
                        'data' => array(
                            'src' => $imageUrl
                        )
                    ));
                }

                $pos = strpos($content, $imageSrc);

                if ($pos !== false) {
                    $content = substr_replace($content, $imageDataSrc, $pos, strlen($imageSrc));
                }

                unset($imageDataSrc);
                unset($imageSrc);

                continue;
            }

            if ($isStream) {
                TOPSEOHelper::output(array(
                    'status' => true,
                    'action' => 'TOPSEODownloadImageContent',
                    'data' => array(
                        'src' => $imageUrl,
                        'attachment_id' => $attachId
                    )
                ));
            }

            $localImageUrl = wp_get_attachment_url($attachId);
            $content = str_replace($imageDataSrc, $localImageUrl, $content);
            $pos = strpos($content, $imageSrc);

            if ($pos !== false) {
                $content = substr_replace($content, $localImageUrl, $pos, strlen($imageSrc));
            }

            unset($imageDataSrc);
            unset($imageSrc);
        }
    }

    return $content;
}
