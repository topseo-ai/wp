<?php

add_action('admin_menu', 'topseoSettingsSubmenu');
add_filter('plugin_action_links_topseoai/index.php', 'topseoSettingsLink');

function topseoSettingsSubmenu()
{
    add_submenu_page(
        'options-general.php', // parent page slug
        'TOPSEO.AI Setting',
        'TOPSEO.AI',
        'manage_options',
        'topseo_settings',
        'topseoSettingsPageCallback'
    );
}

function topseoSettingsPageCallback()
{
    include_once __DIR__ . "/../web/settings.php";
}

function topseoSettingsLink($links)
{
    // Build and escape the URL.
    $url = esc_url(add_query_arg(
        'page',
        'topseo_settings',
        get_admin_url() . 'options-general.php'
    ));
    // Create the link.
    $settings_link = "<a href='$url'>" . __('Settings') . '</a>';
    // Adds the link to the end of the array.
    array_push(
        $links,
        $settings_link
    );
    return $links;
}