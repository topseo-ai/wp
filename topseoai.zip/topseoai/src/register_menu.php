<?php

add_action('admin_menu', 'topseoSettingsSubmenu');

function topseoSettingsSubmenu()
{
    add_submenu_page(
        'options-general.php', // parent page slug
        'TOPSEO.AI Setting',
        'TOPSEO.AI',
        'manage_options',
        'topseo_settings',
        'topseoSettingsPageCallback'
    );
}

function topseoSettingsPageCallback()
{
    include_once __DIR__ . "/../web/settings.php";
}