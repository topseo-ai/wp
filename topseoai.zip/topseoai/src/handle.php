<?php

function TOPSEOAddPost($params)
{
    return wp_insert_post($params, true);
}

function TOPSEOUpdatePost($params)
{
    return wp_insert_post($params, true);
}

function TOPSEOAddCategories($postId, $params)
{
    $taxCategory = TOPSEOHelper::shiftParam($params, TOPSEO_POST_CATE_NAME, 'category');
    $postCategories = TOPSEOHelper::shiftParam($params, TOPSEO_POST_CATEGORIES, '');
    return wp_set_post_terms($postId, $postCategories, $taxCategory);
}

function TOPSEOAddFeaturedImage($postId, $params)
{
    $imageFile = TOPSEOHelper::shiftParam($params, TOPSEO_POST_FEATURED_IMAGE);
    if (isset($imageFile)) {
        $fileType = wp_check_filetype($imageFile, null);
        $attachmentData = TOPSEOHelper::getAttachmentData($imageFile, $fileType['type']);
        return wp_insert_attachment($attachmentData, $imageFile, $postId, true);
    }

    return 0;
}

function TOPSEOAddTags($postId, $params)
{
    $tags = TOPSEOHelper::shiftParam($params, TOPSEO_POST_TAGS);
    if (isset($tags)) {
        return wp_set_post_tags($postId, $tags);
    }

    return 0;
}

function TOPSEOAddPostFormat($postId, $params)
{
    $postFormat = TOPSEOHelper::shiftParam($params, TOPSEO_POST_FORMAT);
    if (isset($postFormat)) {
        return wp_set_post_terms($postId, $postFormat, TOPSEO_POST_FORMAT);
    }

    return 0;
}