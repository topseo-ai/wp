<?php

add_action('admin_init', 'topseoSettingsFields');
add_action('admin_notices', 'topseoSettingsNotice');
add_action('admin_head', 'topseoSettingsStyle');

function topseoSettingsFields()
{
    // I created variables to make the things clearer
    $page_slug = 'topseo_settings';
    $option_group = 'topseo_settings';

    $apiKey = get_option(TOPSEO_API_KEY_DEFINITION);

    if (TOPSEO_CHECK_VALIDATED) {
        if (isset($apiKey) && !empty($apiKey)) {
            $validateResponse = TOPSEORequest::validate($apiKey);

            if (isset($validateResponse['data']['introduce_setting'])) {
                TOPSEOHelper::setOption(TOPSEO_INTRODUCE_SETTING, $validateResponse['data']['introduce_setting']);
            }
        } else {
            add_option(TOPSEO_INTRODUCE_SETTING, '');
        }
    }

    // 1. create section
    add_settings_section(
        'topseo_section_id',
        '',
        'topseoIntro',
        $page_slug
    );

    // 2. register fields
    register_setting($option_group, TOPSEO_API_KEY_DEFINITION, 'topseoApiKeyVerify');
    register_setting($option_group, TOPSEO_USER_UPDATE_DEFINITION);

    // 3. add fields
    add_settings_field(
        TOPSEO_API_KEY_DEFINITION,
        'Api Key',
        'topseoApiKeyBox', // function to print the field
        $page_slug,
        'topseo_section_id',
        array(
            'name' => TOPSEO_API_KEY_DEFINITION,
            'user_update' => TOPSEO_USER_UPDATE_DEFINITION,
            'response' => isset($validateResponse) ? $validateResponse : array()
        )
    );
}

function topseoIntro($args)
{
    echo get_option(TOPSEO_INTRODUCE_SETTING);
}

function topseoApiKeyBox($args)
{
    if (!empty($args['response'])) {
        $response = $args['response'];
    }

    printf(
        '<input class="topseo-input" type="text" id="%s" name="%s" value="%s" />',
        $args['name'],
        $args['name'],
        get_option($args['name'])
    );

    if (isset($response['code']) && $response['code'] != 0) {
        if ($response['status']) {
            printf(base64_decode(TOPSEO_TICKS_SUCCESS), $response['message']);
        } else {
            printf(base64_decode(TOPSEO_TICKS_FAILED), isset($response['message']) ? $response['message'] : TOPSEO_MESSAGE_FAILED_DEFAULT);
        }
    } else {
        if (get_option(TOPSEO_API_KEY_VERIFY) == 1) {
            printf(base64_decode(TOPSEO_TICKS_SUCCESS), "Api Key is activated");
        } else {
            printf(base64_decode(TOPSEO_TICKS_FAILED), "Api Key is not activated");
        }
    }

    printf(
        '<input type="hidden" id="%s" name="%s" value="%s" />',
        $args['user_update'],
        $args['user_update'],
        get_current_user_id()
    );
}

function topseoApiKeyVerify($apiKey)
{
    if (empty($apiKey) || !$apiKey) {
        add_settings_error(
            'topseo_settings_errors',
            'must-be-required',
            'Api Key must be required',
            'error'
        );

        $apiKey = get_option(TOPSEO_API_KEY_DEFINITION);
    } else {
        $result = TOPSEORequest::verify($apiKey);
        if ($result['status']) {
            add_settings_error(
                'topseo_settings_success',
                'validate-api-key-success',
                'Your Api Key is validated !!',
                'success'
            );

            TOPSEOHelper::setOption(TOPSEO_API_KEY_VERIFY, 1);
        } else {
            add_settings_error(
                'topseo_settings_success',
                'validate-api-key-success',
                'Your Api Key is updated. Please access https://app.topseo.ai/customfield/edit?domain=' . $_SERVER['SERVER_NAME'] . ' and click Verify button to finish verifying',
                'success'
            );

            TOPSEOHelper::setOption(TOPSEO_API_KEY_VERIFY, 0);
        }
    }

    return $apiKey;
}

function topseoSettingsNotice()
{
    $settings_errors = get_settings_errors('topseo_settings_errors');
    // if we have any errors, exit
    if (!empty($settings_errors)) {
        return;
    }
}

function topseoSettingsStyle()
{
    echo "<style>" . file_get_contents(__DIR__ . "/../web/styles.css") . "</style>";
}
