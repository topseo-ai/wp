<?php

add_action('admin_init', 'topseoSettingsFields');
add_action('admin_notices', 'topseoSettingsNotice');
add_action('admin_head', 'topseoSettingsStyle');

function topseoSettingsFields()
{
    // I created variables to make the things clearer
    $page_slug = 'topseo_settings';
    $option_group = 'topseo_settings';

    TOPSEOHelper::setOption(TOPSEO_INTRODUCE_SETTING, TOPSEO_INTRODUCE_CONTENT);

    // 1. create section
    add_settings_section(
        'topseo_section_id',
        '',
        'topseoIntro',
        $page_slug
    );

    // 2. register fields
    register_setting($option_group, TOPSEO_API_KEY_DEFINITION, 'topseoApiKeyVerify');
    register_setting($option_group, TOPSEO_USER_UPDATE_DEFINITION);

    // 3. add fields
    add_settings_field(
        TOPSEO_API_KEY_DEFINITION,
        'Api Key',
        'topseoApiKeyBox', // function to print the field
        $page_slug,
        'topseo_section_id',
        array(
            'name' => TOPSEO_API_KEY_DEFINITION,
            'user_update' => TOPSEO_USER_UPDATE_DEFINITION
        )
    );
}

function topseoIntro($args)
{
    echo get_option(TOPSEO_INTRODUCE_SETTING);
}

function topseoApiKeyBox($args)
{
    printf(
        '<input class="topseo-input" type="text" id="%s" name="%s" value="%s" />',
        $args['name'],
        $args['name'],
        get_option($args['name'])
    );

    printf(
        '<input type="hidden" id="%s" name="%s" value="%s" />',
        $args['user_update'],
        $args['user_update'],
        get_current_user_id()
    );
}

function topseoApiKeyVerify($apiKey)
{
    if (empty($apiKey) || !$apiKey) {
        add_settings_error(
            'topseo_settings_errors',
            'must-be-required',
            'Api Key must be required',
            'error'
        );

        $apiKey = get_option(TOPSEO_API_KEY_DEFINITION);
    } else {
        add_settings_error(
            'topseo_settings_success',
            'validate-api-key-success',
            'Your Api Key is updated. Please access https://app.topseo.ai/customfield/edit?domain=' . $_SERVER['SERVER_NAME'] . ' and click Verify button to finish verifying',
            'success'
        );

        TOPSEOHelper::setOption(TOPSEO_API_KEY_VERIFY, 0);
    }

    return $apiKey;
}

function topseoSettingsNotice()
{
    $settings_errors = get_settings_errors('topseo_settings_errors');
    // if we have any errors, exit
    if (!empty($settings_errors)) {
        return;
    }
}

function topseoSettingsStyle()
{
    echo "<style>" . file_get_contents(__DIR__ . "/../web/styles.css") . "</style>";
}
