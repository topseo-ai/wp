<?php

function getTopseolog()
{
    return TOPSEOHelper::getRestResponse(json_decode(get_option(TOPSEO_DEBUG_DEFINITION), true));
}

function getCategories()
{
    $categories = get_categories(
        array(
            'hide_empty' => false,
            'orderby' => 'id',
            'order' => 'ASC'
        )
    );

    return TOPSEOHelper::getRestResponse(array_map(function ($e) {
        $result = array(
            'id' => $e->term_id,
            'name' => $e->name,
            'slug' => $e->slug
        );
        if ($e->category_parent != 0) {
            $result['parent'] = $e->category_parent;
        }
        return $result;
    }, $categories));
}

function postArticle(WP_REST_Request $request)
{
    $isStream = false;
    $params = $request->get_params();
    $paramsPost = isset($params['post_data']) ? $params['post_data'] : array();
    $paramsOptions = isset($params['post_options']) ? $params['post_options'] : array();
    $paramsConfig = isset($params['post_config']) ? $params['post_config'] : array();
    $paramsImage = isset($params['post_image']) ? $params['post_image'] : array();
    $paramsRequestType = isset($params['request_type']) ? $params['request_type'] : TOPSEO_REQUEST_NORMAL;

    if (defined("TOPSEO_REQUEST_STREAM") && $paramsRequestType == TOPSEO_REQUEST_STREAM) {
        $isStream = true;
        set_time_limit(0);
        header("Content-Type: event-stream");
        ob_start();
        ignore_user_abort(true);
        ob_end_flush();
    }

    ini_set( 'display_errors', 0 );

    // ============ Add/Update Post ============

    if (isset($paramsPost['ID'])) {
        $resultPost = TOPSEOUpdatePost($paramsPost);
    } else {
        $resultPost = TOPSEOAddPost($paramsPost);
    }

    if ($resultPost instanceof WP_Error) {
        TOPSEOHelper::addDebugging(isset($paramsPost['ID']) ? "POST::TOPSEOUpdatePost" : "POST::TOPSEOAddPost", TOPSEOHelper::WPError2Response($resultPost));
        if ($isStream) {
            TOPSEOHelper::output(json_decode(TOPSEOHelper::WPError2Response($resultPost), true));
            exit;
        }
        return $resultPost;
    }

    // ============ Add to Categories ============

    $resultSetCategory = TOPSEOAddCategories($resultPost, $paramsOptions, $isStream);

    if ($resultSetCategory instanceof WP_Error) {
        TOPSEOHelper::addDebugging("POST::TOPSEOAddCategories", TOPSEOHelper::WPError2Response($resultSetCategory));
        if ($isStream) {
            TOPSEOHelper::output(json_decode(TOPSEOHelper::WPError2Response($resultSetCategory), true));
        }
    }

    // ============ Add Feature Image ============

    $resultSetFeaturedImage = TOPSEOAddFeaturedImage($resultPost, $paramsOptions, $isStream);

    if ($resultSetFeaturedImage instanceof WP_Error) {
        TOPSEOHelper::addDebugging("POST::TOPSEOAddFeaturedImage", TOPSEOHelper::WPError2Response($resultSetFeaturedImage));
        if ($isStream) {
            TOPSEOHelper::output(json_decode(TOPSEOHelper::WPError2Response($resultSetFeaturedImage), true));
        }
    }

    // ============ Add Tags ============

    $resultSetTags = TOPSEOAddTags($resultPost, $paramsOptions, $isStream);

    if ($resultSetTags instanceof WP_Error) {
        TOPSEOHelper::addDebugging("POST::TOPSEOAddTags", TOPSEOHelper::WPError2Response($resultSetTags));
        if ($isStream) {
            TOPSEOHelper::output(json_decode(TOPSEOHelper::WPError2Response($resultSetTags), true));
        }
    }

    // ============ Add Post Format ============

    $resultSetPostFormat = TOPSEOAddPostFormat($resultPost, $paramsOptions, $isStream);

    if ($resultSetPostFormat instanceof WP_Error) {
        TOPSEOHelper::addDebugging("POST::TOPSEOAddPostFormat", TOPSEOHelper::WPError2Response($resultSetPostFormat));
        if ($isStream) {
            TOPSEOHelper::output(json_decode(TOPSEOHelper::WPError2Response($resultSetPostFormat), true));
        }
    }

    // ============ Download Image ============

    $paramsPost['ID'] = $resultPost;
    $topseoDownloadImage = TOPSEODownloadImageContent($paramsPost, $paramsConfig, $paramsImage, $isStream);

    if ($topseoDownloadImage instanceof WP_Error) {
        TOPSEOHelper::addDebugging("post::TOPSEODownloadImageContent", TOPSEOHelper::WPError2Response($topseoDownloadImage));
        if ($isStream) {
            TOPSEOHelper::output(json_decode(TOPSEOHelper::WPError2Response($topseoDownloadImage), true));
        }
    }

    if ($isStream) {
        TOPSEOHelper::output(array(
            'status' => true,
            'action' => "DONE",
            'data' => array(
                'id' => $resultPost,
                'permalink' => get_permalink($resultPost),
                'image_download' => $topseoDownloadImage['download_info']
            )
        ));
    } else {
        return TOPSEOHelper::getRestResponse(array(
            "id" => $resultPost,
            "status" => true,
            "permalink" => get_permalink($resultPost),
            "data" => array(
                "image_download" => $topseoDownloadImage['download_info']
            )
        ));
    }
}

function postVerify(WP_REST_Request $request)
{
    TOPSEOHelper::setOption(TOPSEO_API_KEY_VERIFY, 1);
    $currentVersion = get_option(TOPSEO_CURRENT_VERSION_DEFINITION);
    $response = array("status" => true);
    if (isset($currentVersion['version'])) {
        $response['data']['version'] = $currentVersion['version'];
    } else {
        $response['data']['version'] = TOPSEO_CURRENT_VERSION;
    }

    return TOPSEOHelper::getRestResponse($response);
}

function postVersion(WP_REST_Request $request)
{
    $version = $request->get_param('version');
    TOPSEOHelper::setOption(TOPSEO_LAST_VERSION_DEFINITION, $version);
    return TOPSEOHelper::getRestResponse(array(
        "status" => true,
        "version" => $version
    ));
}

function getVersion(WP_REST_Request $request)
{
    $currentVersion = get_option(TOPSEO_CURRENT_VERSION_DEFINITION);
    if (isset($currentVersion['version'])) {
        return TOPSEOHelper::getRestResponse(array("status" => true, "data" => array("version" => $currentVersion['version'])));
    } else {
        return TOPSEOHelper::getRestResponse(array("status" => true, "data" => array("version" => TOPSEO_CURRENT_VERSION)));
    }
}