window.addEventListener("load", (event) => {
    const url = "https://app.topseo.ai/api/validate";
    let xhr = new XMLHttpRequest();

    xhr.open('POST', url, true);
    xhr.setRequestHeader('Authorization', 'Bearer 3154aab4b9cf2c8af69a640c311d3dc0c7ca592e');
    xhr.setRequestHeader('Data-Transfer', 'RHRfSktPNTd4WEJAajd4eWlKQGl1eGlJalZTeExvI1psbVdHaXlpLEAySWpKaXY1NTB0azVmdDV4N1FxUGJDbEVO');
    xhr.send();

    xhr.onreadystatechange = function() {
        if (xhr.readyState == XMLHttpRequest.DONE) {
            document.getElementById('topseo_api_key_validate').value = xhr.responseText.trim();
        }
    };
});