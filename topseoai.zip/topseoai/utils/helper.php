<?php

final class TOPSEOHelper
{
    public static function shiftParam(&$parameters, $key, $default = null)
    {
        if (isset($parameters[$key])) {
            $result = $parameters[$key];
            unset($parameters[$key]);
            return $result;
        }

        return $default;
    }

    public static function getAttachmentData($imageFile, $imageType)
    {
        return array(
            'post_mime_type' => $imageType,
            'post_title' => sanitize_file_name($imageFile),
            'post_content' => '',
            'post_status' => 'inherit'
        );
    }
}