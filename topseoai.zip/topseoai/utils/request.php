<?php

final class TOPSEORequest
{
    public static function getPluginInfo($apiKey)
    {
        $url = TOPSEO_PACKAGE_INFO . self::getTimeRequestQuery();
        $response = self::request($url, 'GET', $apiKey, TOPSEOHelper::getDataRequest());
        return json_decode($response, true);
    }

    public static function verify($apiKey)
    {
        $url = TOPSEO_API_ENDPOINT . TOPSEO_API_VERIFY_PATH . self::getTimeRequestQuery();
        $response = self::request($url, 'POST', $apiKey, TOPSEOHelper::getDataRequest());
        return json_decode($response, true);
    }

    public static function validate($apiKey)
    {
        $url = TOPSEO_API_ENDPOINT . TOPSEO_API_VALIDATE_PATH . self::getTimeRequestQuery();
        $response = self::request($url, 'POST', $apiKey, TOPSEOHelper::getDataRequest());
        return json_decode($response, true);
    }

    public static function syncCategories($apiKey)
    {
        $url = TOPSEO_API_ENDPOINT . TOPSEO_API_SYNC_CATEGORIES_PATH . self::getTimeRequestQuery();
        $response = self::request($url, 'POST', $apiKey, TOPSEOHelper::getDataRequest());
        return json_decode($response, true);
    }

    protected static function request($url, $method, $apiKey, $postBody = null)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => self::getHeader($apiKey, $postBody),
        ));

        $response = curl_exec($curl);
        if (curl_errno($curl)) {
            $response = json_encode(array(
                'status' => false,
                'code' => 0,
                'message' => curl_error($curl)
            ));
        }

        curl_close($curl);
        TOPSEOHelper::addDebugging("Request::$url", $response);
        return $response;
    }

    protected static function getHeader($apiKey, $postBody)
    {
        $dataTransfer = array_merge(array('domain' => $_SERVER['SERVER_NAME']), isset($postBody) ? $postBody : array());
        $dataTransfer = json_encode($dataTransfer);
        $dataTransfer = TOPSEOHash::encode($dataTransfer);

        return array(
            "Data-Transfer: $dataTransfer",
            "Authorization: Bearer $apiKey"
        );
    }

    protected static function getTimeRequestQuery()
    {
        return "?t=" . microtime(true);
    }
}