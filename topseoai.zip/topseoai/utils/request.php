<?php

final class TOPSEORequest
{
    public static function verify($apiKey)
    {
        $url = TOPSEO_API_ENDPOINT . TOPSEO_API_VERIFY_PATH;
        $response = self::request($url, 'POST', $apiKey, array("uid" => get_current_user_id()));
        return json_decode($response, true);
    }

    public static function validate($apiKey)
    {
        $url = TOPSEO_API_ENDPOINT . TOPSEO_API_VALIDATE_PATH;
        $response = self::request($url, 'POST', $apiKey, array("uid" => get_current_user_id()));
        return json_decode($response, true);
    }

    public static function syncCategories($apiKey)
    {
        $url = TOPSEO_API_ENDPOINT . TOPSEO_API_SYNC_CATEGORIES_PATH;
        $response = self::request($url, 'POST', $apiKey);
        return json_decode($response, true);
    }

    protected static function request($url, $method, $apiKey, $postBody = null)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => self::getHeader($apiKey, $postBody),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }

    protected static function getHeader($apiKey, $postBody)
    {
        $dataTransfer = array_merge(array('domain' => $_SERVER['SERVER_NAME']), isset($postBody) ? $postBody : array());
        $dataTransfer = json_encode($dataTransfer);
        $dataTransfer = TOPSEOHash::encode($dataTransfer);

        return array(
            "Data-Transfer: $dataTransfer",
            "Authorization: Bearer $apiKey"
        );
    }
}