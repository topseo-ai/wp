<?php

class TOPSEOHash
{
    public static function encode($a)
    {
        $t = time();
        $a = strlen($t) . $t . $a;
        $l = strlen($a);
        $a = str_split($a);
        $a = self::xd($a, $l - 9);
        $a = self::xd($a, $l - 8);
        $a = array_reverse($a);
        $a = self::xd($a, $l - 6);
        $a = self::xd($a, $l - 12);
        $a = array_reverse($a);
        $a = self::xd($a, $l - 7);
        $a = self::xd($a, $l - 13);
        $a = array_reverse($a);
        $a = self::xd($a, $l - 4);
        $a = self::xd($a, $l - 11);
        $a = self::vd($a, 13);
        $a = self::vd($a, 7, true);
        $a = implode($a);
        $a = self::md($a, 5, (strlen($a) / 2) + 1);
        $a = self::e($a);
        return base64_encode($a);
    }
    
    public static function decode($a)
    {
        $a = base64_decode($a);
        $a = self::d($a);
        $a = substr_replace($a, '', ((strlen($a) - 5) / 2) + 1, 5);
        $a = str_split($a);
        $a = array_slice($a, 13);
        $a = array_reverse($a);
        $a = array_slice($a, 7);
        $a = array_reverse($a);
        $l = count($a);
        $a = self::xd($a, $l - 11);
        $a = self::xd($a, $l - 4);
        $a = array_reverse($a);
        $a = self::xd($a, $l - 13);
        $a = self::xd($a, $l - 7);
        $a = array_reverse($a);
        $a = self::xd($a, $l - 12);
        $a = self::xd($a, $l - 6);
        $a = array_reverse($a);
        $a = self::xd($a, $l - 8);
        $a = self::xd($a, $l - 9);
        $a = implode($a);
        $tl = substr($a, 0, 2);
        return substr($a, intval($tl) + 2, strlen($a) - 2);
    }

    protected static function xd($a, $b)
    {
        $c = $a[0];
        $a[0] = $a[$b % count($a)];
        $a[$b] = $c;
        return $a;
    }

    protected static function vd($a, $b, $c = false)
    {
        if ($c) {
            return array_merge($a, str_split(self::dd($b)));
        } else {
            return array_merge(str_split(self::dd($b)), $a);
        }
    }

    protected static function md($a, $b, $c)
    {
        return implode(self::dd($b), str_split($a, $c));
    }

    protected static function dd($length = 10)
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    protected static function e($a)
    {
        $characters = self::ar(TOPSEO_HASH_DEFINITION);
        $mappers = self::ar(TOPSEO_HASH_MAPPING);
        $c = strlen($a);
        for ($i = 0; $i < $c; $i++) {
            $a[$i] = self::ap($a[$i], $characters, $mappers);
        }

        return $a;
    }

    protected static function d($a)
    {
        $characters = self::ar(TOPSEO_HASH_DEFINITION);
        $mappers = self::ar(TOPSEO_HASH_MAPPING);
        $c = strlen($a);
        for ($i = 0; $i < $c; $i++) {
            $a[$i] = self::ap($a[$i], $mappers, $characters);
        }

        return $a;
    }

    protected static function ar($a)
    {
        return str_split($a);
    }

    protected static function ap($a, $b, $c)
    {
        $k = array_search($a, $b);
        return $c[$k];
    }
}