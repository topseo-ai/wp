<?php
/**
 * Plugin Name: TOPSEO.AI
 * Plugin URI:  https://topseo.ai
 * Description: Sync data between topseo.ai and wordpress site
 * Version:     1.0.0
 * Author:      khanhhq
 * Author URI:  https://www.facebook.com/groups/topseoai
 *
 * @package Meta Box
 */

include_once __DIR__ . "/router.php";
include_once __DIR__ . "/definition.php";
include_once __DIR__ . "/utils/request.php";
include_once __DIR__ . "/utils/hash.php";
include_once __DIR__ . "/utils/helper.php";
include_once __DIR__ . "/src/controller.php";
include_once __DIR__ . "/src/handle.php";
include_once __DIR__ . "/src/register_bulk.php";
include_once __DIR__ . "/src/register_menu.php";
include_once __DIR__ . "/src/register_form.php";
include_once __DIR__ . "/src/validation.php";
