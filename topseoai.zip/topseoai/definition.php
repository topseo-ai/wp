<?php

define("TOPSEO_HASH_DEFINITION", '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_#@{}",/:.');
define("TOPSEO_HASH_MAPPING", '7xk6mG50tc2DQJoLb/@8X}I,jnZYOMV#Rs_.FB:AUhHprW{e-qKzE1PTNC39l"4awdvfiugyS');
define("TOPSEO_API_KEY_DEFINITION", "topseo_api_key");
define("TOPSEO_USER_UPDATE_DEFINITION", "topseo_user_update");

define("TOPSEO_API_ENDPOINT", "https://app.topseo.ai/api");
define("TOPSEO_API_VERIFY_PATH", "/verify");
define("TOPSEO_API_VALIDATE_PATH", "/validate");
define("TOPSEO_API_SYNC_CATEGORIES_PATH", "/sync_categories");
define("TOPSEO_API_NAMESPACE", "topseo/v1");

define("TOPSEO_POST_CATE_NAME", 'post_category_name');
define("TOPSEO_POST_CATEGORIES", 'post_categories');
define("TOPSEO_POST_FEATURED_IMAGE", 'post_featured_image');
define("TOPSEO_POST_TAGS", 'post_tags');
define("TOPSEO_POST_FORMAT", 'post_format');

define("TOPSEO_CONFIG_DOWNLOAD_IMAGE", 'download_images');
