<?php

add_action('rest_api_init', function () {
    $routes = getRoutes();
    foreach ($routes as $route) {
        register_rest_route(TOPSEO_API_NAMESPACE, "/{$route['route']}", array(
            'methods' => $route['method'],
            'callback' => $route['controller'],
        ));
    }
});

function getRoutes()
{
    $functionFinder = '/function[\s\n]+(\S+)[\s\n]*\(/';
    $functionArray = array();
    $fileContents = file_get_contents(__DIR__ . '/src/controller.php' );
    preg_match_all( $functionFinder , $fileContents , $functionArray );
    $result = array();
    foreach($functionArray[1] as $func) {
        list($method, $route) = explode('_', strtolower(preg_replace('/(?<!^)[A-Z]/', '_$0', $func)));
        $result[] = array(
            'method' => strtoupper($method),
            'route' => $route,
            'controller' => $func
        );
    }

    return $result;
}