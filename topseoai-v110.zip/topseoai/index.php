<?php
/**
 * Plugin Name: TOPSEO.AI
 * Plugin URI:  https://topseo.ai
 * Description: Sync data between TOPSEO.AI and Wordpress site
 * Version:     1.1.0
 * Author:      TOPSEO.AI
 * Author URI:  https://www.facebook.com/groups/topseoai
 * Update URI:  http://emperium.local/wp-content/plugins/topseoai/info.json
 *
 * @package Meta Box
 */

include_once __DIR__ . "/router.php";
include_once __DIR__ . "/definition.php";
include_once __DIR__ . "/utils/request.php";
include_once __DIR__ . "/utils/hash.php";
include_once __DIR__ . "/utils/helper.php";
include_once __DIR__ . "/src/controller.php";
include_once __DIR__ . "/src/handle.php";
include_once __DIR__ . "/src/register_bulk.php";
include_once __DIR__ . "/src/register_menu.php";
include_once __DIR__ . "/src/register_form.php";
include_once __DIR__ . "/src/validation.php";
include_once __DIR__ . "/update.php";
