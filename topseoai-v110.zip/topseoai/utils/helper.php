<?php

final class TOPSEOHelper
{
    public static function shiftParam(&$parameters, $key, $default = null)
    {
        if (isset($parameters[$key])) {
            $result = $parameters[$key];
            unset($parameters[$key]);
            return $result;
        }

        return $default;
    }

    public static function wpInsertAttachmentFromUrl($url, $parentPostId = null)
    {
        if (!class_exists('WP_Http')) {
            require_once ABSPATH . WPINC . '/class-http.php';
        }

        if(!function_exists('wp_get_current_user')) {
            include(ABSPATH . "wp-includes/pluggable.php");
        }

        $http = new WP_Http();
        $response = $http->request($url);
        if (200 !== $response['response']['code']) {
            return false;
        }

        $upload = wp_upload_bits(basename($url), null, $response['body']);
        if (!empty($upload['error'])) {
            return false;
        }

        $filePath = $upload['file'];
        $fileName = basename($filePath);
        $fileType = wp_check_filetype($fileName, null);
        $attachmentTitle = sanitize_file_name(pathinfo($fileName, PATHINFO_FILENAME));
        $wpUploadDir = wp_upload_dir();

        $postInfo = array(
            'guid' => $wpUploadDir['url'] . '/' . $fileName,
            'post_mime_type' => $fileType['type'],
            'post_title' => $attachmentTitle,
            'post_content' => '',
            'post_status' => 'inherit',
        );

        // Create the attachment.
        $attachId = wp_insert_attachment($postInfo, $filePath, $parentPostId);

        // Include image.php.
        require_once ABSPATH . 'wp-admin/includes/image.php';

        // Generate the attachment metadata.
        $attachData = wp_generate_attachment_metadata($attachId, $filePath);

        // Assign metadata to attachment.
        wp_update_attachment_metadata($attachId, $attachData);

        return $attachId;
    }
}