<?php

add_filter('rest_request_before_callbacks', 'wpdocsAuthorizeApiRequests', 10, 3);

function wpdocsAuthorizeApiRequests($response, $handler, WP_REST_Request $request)
{
    $route = $request->get_route();
    if (strpos($route, 'topseo') !== false) {
        $authorization = $request->get_header('authorization');

        if (!$authorization) {
            return new WP_Error('authorization', 'Unauthorized Access.', array('status' => 401));
        }

        if (substr($authorization, 0, 6) !== 'Bearer') {
            return new WP_Error('authorization', 'Invalid Authorization.', array('status' => 401));
        }

        $apiKey = trim(substr($authorization, 6));

        if ($apiKey != get_option('topseo_api_key')) {
            return new WP_Error('forbidden', 'Access Forbidden.', array('status' => 403));
        }
    }

    return $response;
}