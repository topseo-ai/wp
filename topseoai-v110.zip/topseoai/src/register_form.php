<?php

add_action('admin_init', 'topseoSettingsFields');
add_action('admin_notices', 'topseoSettingsNotice');
add_action('admin_head', 'topseoSettingsStyle');

function topseoSettingsFields()
{
    // I created variables to make the things clearer
    $page_slug = 'topseo_settings';
    $option_group = 'topseo_settings';

    $apiKey = get_option(TOPSEO_API_KEY_DEFINITION);

    if (isset($apiKey) && !empty($apiKey)) {
        $validateResponse = TOPSEORequest::validate($apiKey);
        $topseoIntroduceSetting = get_option(TOPSEO_INTRODUCE_SETTING);
        $optionIntroduceMethod = !$topseoIntroduceSetting ? 'add_option' : 'update_option';

        if (isset($validateResponse['data']['introduce_setting'])) {
            $optionIntroduceMethod(TOPSEO_INTRODUCE_SETTING, $validateResponse['data']['introduce_setting']);
        } else {
            $optionIntroduceMethod(TOPSEO_INTRODUCE_SETTING, '');
        }
    } else {
        add_option(TOPSEO_INTRODUCE_SETTING, '');
    }

    // 1. create section
    add_settings_section(
        'topseo_section_id',
        '',
        'topseoIntro',
        $page_slug
    );

    // 2. register fields
    register_setting($option_group, TOPSEO_API_KEY_DEFINITION, 'topseoApiKeyVerify');
    register_setting($option_group, TOPSEO_USER_UPDATE_DEFINITION);

    // 3. add fields
    add_settings_field(
        TOPSEO_API_KEY_DEFINITION,
        'Api Key',
        'topseoApiKeyBox', // function to print the field
        $page_slug,
        'topseo_section_id',
        array(
            'name' => TOPSEO_API_KEY_DEFINITION,
            'user_update' => TOPSEO_USER_UPDATE_DEFINITION,
            'response' => isset($validateResponse) ? $validateResponse : array()
        )
    );
}

function topseoIntro($args)
{
    echo get_option(TOPSEO_INTRODUCE_SETTING);
}

function topseoApiKeyBox($args)
{
    if (!empty($args['response'])) {
        $response = $args['response'];
    }

    printf(
        '<input class="topseo-input" type="text" id="%s" name="%s" value="%s" />',
        $args['name'],
        $args['name'],
        get_option($args['name'])
    );

    if (isset($response)) {
        if ($response['status']) {
            printf(base64_decode(TOPSEO_TICKS_SUCCESS), $response['message']);
        } else {
            printf(base64_decode(TOPSEO_TICKS_FAILED), isset($response['message']) ? $response['message'] : TOPSEO_MESSAGE_FAILED_DEFAULT);
        }
    }

    printf(
        '<input type="hidden" id="%s" name="%s" value="%s" />',
        $args['user_update'],
        $args['user_update'],
        get_current_user_id()
    );
}

function topseoApiKeyVerify($apiKey)
{
    if (empty($apiKey) || !$apiKey) {
        add_settings_error(
            'topseo_settings_errors',
            'must-be-required',
            'Api Key must be required',
            'error'
        );

        $apiKey = get_option(TOPSEO_API_KEY_DEFINITION);
    } else {
        $result = TOPSEORequest::verify($apiKey);
        if ($result['status']) {
            add_settings_error(
                'topseo_settings_success',
                'validate-api-key-success',
                'Your Api Key is validated !!',
                'success'
            );
        } else {
            add_settings_error(
                'topseo_settings_errors',
                'validate-api-key-failed',
                $result['message'],
                'error'
            );

            $apiKey = get_option(TOPSEO_API_KEY_DEFINITION);
        }
    }

    return $apiKey;
}

function topseoSettingsNotice()
{
    $settings_errors = get_settings_errors('topseo_settings_errors');
    // if we have any errors, exit
    if (!empty($settings_errors)) {
        return;
    }
}

function topseoSettingsStyle()
{
    echo "<style>" . file_get_contents(__DIR__ . "/../web/styles.css") . "</style>";
}
